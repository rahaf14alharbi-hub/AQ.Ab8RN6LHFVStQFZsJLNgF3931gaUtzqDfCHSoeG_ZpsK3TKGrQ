// عدسة المخطِّط — يستقبل صورة الموقع واسم العالِم، ويعيد صورة المكان نفسه بعد المعالجة بمبادئه.
// يعمل على Vercel (Node 18+). المتغيرات المطلوبة: GEMINI_API_KEY
// اختياري: GEMINI_MODEL (اسم نموذج الصور)، ACCESS_CODE (رمز دخول يحمي المفتاح من الاستخدام العام)

const BASE = `Edit this photograph of an existing urban site.
Keep the EXACT same camera position, lens, perspective, framing and horizon line.
Keep the existing buildings' massing, heights and street geometry recognisable: this must read as the same place, improved.
Output a single photorealistic architectural visualisation, the quality of a high-end 3D render, showing this same place after an urban design intervention.
Context: Madinah, Saudi Arabia. Hot arid climate. Respect the local Hijazi and Islamic architectural character and local dress and customs of people.
Do not add any text, labels, logos, signage lettering or watermarks.`;

const PLANNERS = {
  khaldun: `Apply Ibn Khaldun's principles of 'umran from the Muqaddimah: protect people from harm and bring them benefit.
Interventions: shade the walkways with traditional wooden mashrabiya canopies or woven palm-frond pergolas; add a stone sabeel drinking-water fountain; plant date palms and drought-tolerant trees; show neat stone channels that drain rain and flash water; replace hot dark surfaces with light, cool natural stone; give ground floors to local crafts, date sellers and a small souq; create a communal gathering space that binds the neighbourhood together.`,
  lynch: `Apply Kevin Lynch's principles from The Image of the City: make the place legible and memorable.
Interventions: make the main path continuous and unmistakable with a distinctive paving pattern that leads the eye; mark the entrance with a gateway; terminate the vista with a clear landmark visible from afar; form a small node or plaza at the key junction with a fountain or focal element; soften hard edges so they connect instead of divide; give the district a coherent identity through consistent materials, lanterns at a steady rhythm and discreet wayfinding.`,
  jacobs: `Apply Jane Jacobs' principles from The Death and Life of Great American Cities: diversity and eyes on the street.
Interventions: fill every ground floor with a fine-grained mix of small uses (bakery, café, grocer, tailor, bookshop, workshop) with goods and doors opening to the street; add windows and small balconies where residents watch the street; cut a short pedestrian passage through any long block; keep older buildings alongside newer ones; show a lively mix of people of all ages using the street at once — shopkeepers on doorsteps, children, elderly, families.`,
  gehl: `Apply Jan Gehl's principles from Life Between Buildings and Cities for People: design at human scale and 5 km/h.
Interventions: give the street to pedestrians, widen walking space and remove car dominance; add continuous shade from wide-canopy trees and light shade sails; add generous public seating and café seating in the shade; make ground floors active, transparent and varied every few metres (soft edges with planters and doors); warm, low, pedestrian-scale lighting; show people lingering, sitting, talking and children playing, not only passing through.`
};

const FALLBACK_MODELS = ["gemini-3.1-flash-image", "gemini-3.1-flash-image-preview", "gemini-2.5-flash-image"];

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "استخدم POST" });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({ error: "لم يُضبط مفتاح GEMINI_API_KEY في إعدادات الموقع." });

  const body = typeof req.body === "string" ? safeParse(req.body) : (req.body || {});
  const { image, mime, planner, note, code } = body;

  if (process.env.ACCESS_CODE && code !== process.env.ACCESS_CODE)
    return res.status(401).json({ error: "رمز الدخول غير صحيح.", needCode: true });
  if (!PLANNERS[planner]) return res.status(400).json({ error: "عالِم غير معروف." });
  if (!image || typeof image !== "string" || image.length > 6_000_000)
    return res.status(400).json({ error: "الصورة مفقودة أو كبيرة جداً." });

  const extra = typeof note === "string" && note.trim()
    ? `\nNotes from the planner about this site (may be in Arabic): ${note.trim().slice(0, 400)}` : "";
  const prompt = `${BASE}\n\n${PLANNERS[planner]}${extra}`;

  const models = [process.env.GEMINI_MODEL, ...FALLBACK_MODELS].filter(Boolean);
  let lastErr = "تعذّر توليد الصورة.";

  for (const model of models) {
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [
            { text: prompt },
            { inline_data: { mime_type: mime || "image/jpeg", data: image } }
          ] }],
          generationConfig: { responseModalities: ["TEXT", "IMAGE"] }
        })
      });
      const data = await r.json().catch(() => ({}));
      if (r.status === 404) { lastErr = `النموذج ${model} غير متاح.`; continue; }
      if (!r.ok) {
        const msg = data?.error?.message || `خطأ ${r.status}`;
        return res.status(r.status === 429 ? 429 : 502).json({ error: r.status === 429 ? "تم تجاوز حد الاستخدام مؤقتاً. حاول بعد دقيقة." : msg });
      }
      const parts = data?.candidates?.[0]?.content?.parts || [];
      const img = parts.find(p => p.inlineData || p.inline_data);
      if (!img) {
        const why = data?.candidates?.[0]?.finishReason || data?.promptFeedback?.blockReason || "";
        return res.status(422).json({ error: "لم يُرجع النموذج صورة. جرّب صورة أوضح أو عدسة أخرى." + (why ? ` (${why})` : "") });
      }
      const d = img.inlineData || img.inline_data;
      return res.status(200).json({ image: d.data, mime: d.mimeType || d.mime_type || "image/png", model });
    } catch (e) {
      lastErr = "تعذّر الاتصال بخدمة الصور.";
    }
  }
  return res.status(502).json({ error: lastErr });
};

function safeParse(s) { try { return JSON.parse(s); } catch { return {}; } }
